module CPLD_ROM( 
    input [3:0]A, 
    output reg [7:0]Dout); 
    always @(*)
    begin
//Boot ROM in CPLD
        case(A)
      
        4'b0000: Dout = 8'hCA; // DEX     
        4'b0001: Dout = 8'hD0; // BNE 
        4'b0010: Dout = 8'hFD; //  
        4'b0011: Dout = 8'h88; // DEY 
        4'b0100: Dout = 8'hD0; // BNE 
        4'b0101: Dout = 8'hFA; //  
        4'b0110: Dout = 8'h8D; // STA 
        4'b0111: Dout = 8'h00; //  
        4'b1000: Dout = 8'hE4; //      
        4'b1001: Dout = 8'h1A; // INC
        4'b1010: Dout = 8'h80; // BRA 
        4'b1011: Dout = 8'hF4; //  
        4'b1100: Dout = 8'hF0; //  
        4'b1101: Dout = 8'hFF; //  
        4'b1110: Dout = 8'h00; //  
        4'b1111: Dout = 8'h00; //  

        endcase
    end
endmodule