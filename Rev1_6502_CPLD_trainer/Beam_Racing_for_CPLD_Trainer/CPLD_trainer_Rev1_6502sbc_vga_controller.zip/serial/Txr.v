// Copyright (C) 1991-2008 Altera Corporation
// Your use of Altera Corporation's design tools, logic functions 
// and other software and tools, and its AMPP partner logic 
// functions, and any output files from any of the foregoing 
// (including device programming or simulation files), and any 
// associated documentation or information are expressly subject 
// to the terms and conditions of the Altera Program License 
// Subscription Agreement, Altera MegaCore Function License 
// Agreement, or other applicable license agreement, including, 
// without limitation, that your use is for the sole purpose of 
// programming logic devices manufactured by Altera and sold by 
// Altera or its authorized distributors.  Please refer to the 
// applicable agreement for further details.

// PROGRAM		"Quartus II"
// VERSION		"Version 8.1 Build 163 10/28/2008 SJ Full Version"
// CREATED ON	"Wed Dec 24 18:48:26 2008"

module Txr(
	BAUDCLK,
	nRST,
	CLKEN,
	SerWr,
	SDin,
	TxEmpty,
	Sout
);


input	BAUDCLK;
input	nRST;
input	CLKEN;
input	SerWr;
input	[7:0] SDin;
output	TxEmpty;
output	Sout;

wire	SYNTHESIZED_WIRE_0;
wire	SYNTHESIZED_WIRE_1;
wire	SYNTHESIZED_WIRE_2;
wire	SYNTHESIZED_WIRE_29;
wire	SYNTHESIZED_WIRE_4;
wire	SYNTHESIZED_WIRE_6;
wire	SYNTHESIZED_WIRE_8;
wire	SYNTHESIZED_WIRE_30;
wire	SYNTHESIZED_WIRE_31;
wire	SYNTHESIZED_WIRE_12;
wire	SYNTHESIZED_WIRE_14;
wire	SYNTHESIZED_WIRE_16;
wire	SYNTHESIZED_WIRE_18;
wire	SYNTHESIZED_WIRE_20;
wire	SYNTHESIZED_WIRE_21;
wire	SYNTHESIZED_WIRE_23;
wire	SYNTHESIZED_WIRE_25;
reg	SYNTHESIZED_WIRE_32;
wire	SYNTHESIZED_WIRE_27;

assign	TxEmpty = SYNTHESIZED_WIRE_30;
assign	SYNTHESIZED_WIRE_2 = 1;
assign	SYNTHESIZED_WIRE_20 = 0;




assign	SYNTHESIZED_WIRE_1 = SerWr & CLKEN;

assign	SYNTHESIZED_WIRE_29 = SYNTHESIZED_WIRE_0 | SYNTHESIZED_WIRE_1;


\1stage 	b2v_inst24(
	.Din(SDin[7]),
	.SI(SYNTHESIZED_WIRE_2),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_4));


\1stage 	b2v_inst25(
	.Din(SDin[6]),
	.SI(SYNTHESIZED_WIRE_4),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_6));


\1stage 	b2v_inst28(
	.Din(SDin[5]),
	.SI(SYNTHESIZED_WIRE_6),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_8));


\1stage 	b2v_inst29(
	.Din(SDin[4]),
	.SI(SYNTHESIZED_WIRE_8),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_12));


Count4_9	b2v_inst3(
	.sclr(SYNTHESIZED_WIRE_30),
	.clock(BAUDCLK),
	.clk_en(CLKEN),
	.cnt_en(SYNTHESIZED_WIRE_31),
	.cout(SYNTHESIZED_WIRE_23)
	);


\1stage 	b2v_inst30(
	.Din(SDin[3]),
	.SI(SYNTHESIZED_WIRE_12),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_14));


\1stage 	b2v_inst31(
	.Din(SDin[2]),
	.SI(SYNTHESIZED_WIRE_14),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_16));


\1stage 	b2v_inst32(
	.Din(SDin[1]),
	.SI(SYNTHESIZED_WIRE_16),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_18));


\1stage 	b2v_inst33(
	.Din(SDin[0]),
	.SI(SYNTHESIZED_WIRE_18),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_21));


\1stage 	b2v_inst34(
	.Din(SYNTHESIZED_WIRE_20),
	.SI(SYNTHESIZED_WIRE_21),
	.CLK(BAUDCLK),
	.EN(SYNTHESIZED_WIRE_29),
	.L_nS(SerWr),
	.SO(SYNTHESIZED_WIRE_25));



always@(posedge BAUDCLK or negedge nRST)
begin
if (!nRST)
	begin
	SYNTHESIZED_WIRE_32 = 0;
	end
else
	begin
if (CLKEN)
	begin
	SYNTHESIZED_WIRE_32 = ~SYNTHESIZED_WIRE_32 & SerWr | SYNTHESIZED_WIRE_32 & ~SYNTHESIZED_WIRE_23;
	end
	end
end

assign	Sout = SYNTHESIZED_WIRE_30 | SYNTHESIZED_WIRE_25;

assign	SYNTHESIZED_WIRE_0 = SYNTHESIZED_WIRE_31 & SYNTHESIZED_WIRE_32;

assign	SYNTHESIZED_WIRE_30 =  ~SYNTHESIZED_WIRE_32;

assign	SYNTHESIZED_WIRE_31 = CLKEN & SYNTHESIZED_WIRE_27;


count4	b2v_inst8(
	.sclr(SYNTHESIZED_WIRE_30),
	.clock(BAUDCLK),
	.clk_en(CLKEN),
	.cnt_en(CLKEN),
	.cout(SYNTHESIZED_WIRE_27)
	);


endmodule
