ca65 -l TrainerMon.lst -D BASE=0xf000 TrainerMon.65s
cl65 TrainerMon.o -o TrainMon.bin -C TrainerMon.cfg --start-addr 0xf000
bin2hex /o0xf000 TrainMon.bin TrainMon.hex
